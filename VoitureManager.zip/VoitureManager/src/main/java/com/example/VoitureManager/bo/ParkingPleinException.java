package com.example.VoitureManager.bo;

public class ParkingPleinException extends Exception {

	public ParkingPleinException(String string) {
		super();
	}
	
}
