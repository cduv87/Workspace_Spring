package com.example.VoitureManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoitureManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
